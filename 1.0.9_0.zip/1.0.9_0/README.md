TestCase Studio is a platform to record the user actions performed on a web application in English Sentences. It will also generate the XPath and Automation Code for every user action. User can save or copy these recorded steps as a Test case.

Very simple steps to use the tool-
1. Click on the TestCase Studio logo in the tool bar.
2. It will open the TestCase Studio window.
3. Now keep performing your steps, it will automatically write english sentence for every user action.
4. You can download the written steps by clicking on download button.